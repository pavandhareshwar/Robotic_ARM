/***********************************************************************************************//**
 * \file   main.c
 * \brief  Silicon Labs Empty Example Project
 *
 * This example demonstrates the bare minimum needed for a Blue Gecko C application
 * that allows Over-the-Air Device Firmware Upgrading (OTA DFU). The application
 * starts advertising after boot and restarts advertising after a connection is closed.
 ***************************************************************************************************
 * <b> (C) Copyright 2016 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 **************************************************************************************************/

#ifndef GENERATION_DONE
#error You must run generate first!
#endif

/* Board headers */
#include "boards.h"
#include "ble-configuration.h"
#include "board_features.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"
#include "aat.h"

/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"
#ifdef FEATURE_BOARD_DETECTED
#include "bspconfig.h"
#include "pti.h"
#endif

/* Device initialization header */
#include "InitDevice.h"

#ifdef FEATURE_SPI_FLASH
#include "em_usart.h"
#include "mx25flash_spi.h"
#endif /* FEATURE_SPI_FLASH */

#include "em_leuart.h"
#include "em_int.h"
#include "em_core.h"
#include "em_ldma.h"

#include "retargetserial.h"

/***********************************************************************************************//**
 * @addtogroup Application
 * @{
 **************************************************************************************************/

/***********************************************************************************************//**
 * @addtogroup app
 * @{
 **************************************************************************************************/

#ifndef MAX_CONNECTIONS
#define MAX_CONNECTIONS 4
#endif
uint8_t bluetooth_stack_heap[DEFAULT_BLUETOOTH_HEAP(MAX_CONNECTIONS)];

#ifdef FEATURE_PTI_SUPPORT
static const RADIO_PTIInit_t ptiInit = RADIO_PTI_INIT;
#endif

#define ENABLE_TX_FOR_LOOPBACK

/* Gecko configuration parameters (see gecko_configuration.h) */
static const gecko_configuration_t config = {
  .config_flags=0,
  .sleep.flags=SLEEP_FLAGS_DEEP_SLEEP_ENABLE,
  .bluetooth.max_connections=MAX_CONNECTIONS,
  .bluetooth.heap=bluetooth_stack_heap,
  .bluetooth.heap_size=sizeof(bluetooth_stack_heap),
  .bluetooth.sleep_clock_accuracy = 100, // ppm
  .gattdb=&bg_gattdb_data,
  .ota.flags=0,
  .ota.device_name_len=3,
  .ota.device_name_ptr="OTA",
  #ifdef FEATURE_PTI_SUPPORT
  .pti = &ptiInit,
  #endif
};

/* Flag for indicating DFU Reset must be performed */
uint8_t boot_to_dfu = 0;

#define READ_SIZE	4

uint8_t sensor_data_buffer[READ_SIZE];

/** LDMA Descriptor initialization */
static LDMA_Descriptor_t xfer =
		LDMA_DESCRIPTOR_LINKREL_P2M_BYTE(&LEUART0->RXDATA, 	/* Peripheral source address */
				sensor_data_buffer,  						/* Peripheral destination address */
				READ_SIZE,    								/* Number of bytes */
				0);               							/* Link to same descriptor */

/************************************************************************************
 * @function 	LEUART_Interrupt_Enable
 * @params 		None
 * @brief 		Enables the necessary interrupts for LEUART0.
 ************************************************************************************/
void LEUART_Interrupt_Enable(LEUART_TypeDef *LEUART)
{
	uint32_t leuart_if = LEUART->IF;

	/* Clear all the interrupts that may have been set-up inadvertently */
	LEUART->IFC |= leuart_if;

#ifdef ENABLE_TX_FOR_LOOPBACK
	/* Enable TXBL interrupt */
	LEUART_IntEnable(LEUART, LEUART_IF_TXBL);
#endif

	LEUART_IntEnable(LEUART, LEUART_IF_RXDATAV);
}

void LEUART_Setup()
{
#if 0
	const LEUART_Init_TypeDef leuart0_init =
	{
			.enable     = leuartDisable,
			.refFreq    = 0,
			.baudrate   = 9600,
			.databits   = leuartDatabits8,
			.parity     = leuartNoParity,
			.stopbits   = leuartStopbits1
	};

	/* Resetting and initializing LEUART0 */
	LEUART_Reset(LEUART0);
	LEUART_Init(LEUART0, &leuart0_init);

	LEUART0->ROUTEPEN |= LEUART_ROUTEPEN_RXPEN;
	LEUART0->ROUTELOC0 |= LEUART_ROUTELOC0_RXLOC_LOC0;

#ifdef ENABLE_TX_FOR_LOOPBACK
	/* LoopBack Enable */
	LEUART0->CTRL |= LEUART_CTRL_LOOPBK;

	LEUART0->ROUTEPEN |= LEUART_ROUTEPEN_TXPEN;
	LEUART0->ROUTELOC0 |= LEUART_ROUTELOC0_TXLOC_LOC0;
#endif

	/* Enable GPIO for LEUART0. TX is on A1 */
	GPIO_PinModeSet(gpioPortA, 0, gpioModePushPull, 1); /* TX Pin - PA0 */

#ifdef ENABLE_TX_FOR_LOOPBACK
	/* Enable GPIO for LEUART0. RX is on A2 */
	GPIO_PinModeSet(gpioPortA, 1, gpioModeInput, 1); 	/* RX Pin - PA1 */
#endif

	/* Set RXDMAWU to wake up the DMA controller in EM2 */
	LEUART_RxDmaInEM2Enable(LEUART0, true);

	/* Finally enable it */
	LEUART_Enable(LEUART0, leuartEnable);

#if 0
	/* Enable LEUART0 Interrupts */
	LEUART_Interrupt_Enable(LEUART0);

	NVIC_ClearPendingIRQ(LEUART0_IRQn);

	NVIC_EnableIRQ(LEUART0_IRQn);
#endif
#else
	/* Enable peripheral clocks */
	CMU_ClockEnable(cmuClock_HFPER, true);
	/* Configure GPIO pins */
	CMU_ClockEnable(cmuClock_GPIO, true);
	/* To avoid false start, configure output as high */
	GPIO_PinModeSet(RETARGET_TXPORT, RETARGET_TXPIN, gpioModePushPull, 1);
	GPIO_PinModeSet(RETARGET_RXPORT, RETARGET_RXPIN, gpioModeInput, 0);

	LEUART_Init_TypeDef init = LEUART_INIT_DEFAULT;

	/* Enable CORE LE clock in order to access LE modules */
	CMU_ClockEnable(cmuClock_CORELE, true);

	/* Select LFXO for LEUARTs (and wait for it to stabilize) */
	CMU_ClockSelectSet(cmuClock_LFB, cmuSelect_LFXO);
	CMU_ClockEnable(cmuClock_LEUART0, true);

	/* Do not prescale clock */
	CMU_ClockDivSet(cmuClock_LEUART0, cmuClkDiv_1);

	/* Configure LEUART */
	init.enable = leuartDisable;

	LEUART_Init(LEUART0, &init);

	/* Enable pins at default location */
	LEUART0->ROUTELOC0 = (LEUART0->ROUTELOC0 & ~(_LEUART_ROUTELOC0_TXLOC_MASK
			| _LEUART_ROUTELOC0_RXLOC_MASK))
	                    		   | (RETARGET_TX_LOCATION << _LEUART_ROUTELOC0_TXLOC_SHIFT)
								   | (RETARGET_RX_LOCATION << _LEUART_ROUTELOC0_RXLOC_SHIFT);

	LEUART0->ROUTEPEN  = USART_ROUTEPEN_RXPEN | USART_ROUTEPEN_TXPEN;

	/* Set RXDMAWU to wake up the DMA controller in EM2 */
	LEUART_RxDmaInEM2Enable(LEUART0, true);

	/* Finally enable it */
	LEUART_Enable(LEUART0, leuartEnable);
#endif
}

void LDMA_SetUp(void)
{

	/* LDMA transfer configuration for LEUART */
		const LDMA_TransferCfg_t periTransferRx =
				LDMA_TRANSFER_CFG_PERIPHERAL(ldmaPeripheralSignal_LEUART0_RXDATAV);

		xfer.xfer.dstInc  = ldmaCtrlDstIncOne;

		/* Set the bit to trigger the DMA Done Interrupt */
		xfer.xfer.doneIfs = 1;

		/* LDMA initialization mode definition */
		LDMA_Init_t init = LDMA_INIT_DEFAULT;

		/* Enable the interrupts */
		LDMA->IEN = 0x01;
		NVIC_EnableIRQ(LDMA_IRQn);

		/* LDMA initialization */
		LDMA_Init(&init);
		LDMA_StartTransfer(0, (LDMA_TransferCfg_t *)&periTransferRx, &xfer);

}

#if 0
void LEUART0_IRQHandler(void)
{
	uint32_t 	rx_data = 0;
	uint32_t 	tx_data = 0xAA;

	CORE_DECLARE_IRQ_STATE;
	CORE_ENTER_ATOMIC();

	/* RXDATAV Interrupt */
	if ((LEUART0->IF & LEUART_IF_RXDATAV) == LEUART_IF_RXDATAV)
	{
		LEUART_IntClear(LEUART0, LEUART_IF_RXDATAV);

		if (( LEUART0->IF & LEUART_IF_RXDATAV) == LEUART_IF_RXDATAV)
			rx_data = LEUART0->RXDATA;
	}

#ifdef ENABLE_TX_FOR_LOOPBACK
	/* TXBL Interrupt */
	if ((LEUART0->IF & LEUART_IF_TXBL) == LEUART_IF_TXBL)
	{
		LEUART_IntClear(LEUART0, LEUART_IF_TXBL);

		LEUART0->TXDATA = tx_data;
		while((LEUART0->IF & LEUART_IF_TXC) == 0);

		if (( LEUART0->IF & LEUART_IF_RXDATAV) == LEUART_IF_RXDATAV)
			rx_data = LEUART0->RXDATA;
	}
#endif

	CORE_EXIT_ATOMIC();
}
#endif

void Clock_SetUp()
{
	CMU_ClockEnable(cmuClock_CORELE, true); /* To enable the low frequency clock tree */

	/* Enable necessary clocks */
	CMU_OscillatorEnable(cmuOsc_LFXO, true, true); /* To enable the LFXO */
	CMU_ClockSelectSet(cmuClock_LFA, cmuSelect_LFXO); /* To support energy modes EM0-EM2 */

	CMU_ClockEnable(cmuClock_HFPER, true); 	/* To enable the clock tree for Timer peripherals */

	CMU_ClockEnable(cmuClock_GPIO, true);	/* To enable clock to GPIO */

	CMU_ClockSelectSet(cmuClock_LFB, cmuSelect_LFXO); /* To support energy modes EM0-EM2 */

	CMU_ClockEnable(cmuClock_LEUART0, true);    /* Enable LEUART0 clock */
}

/**
 * @brief  Main function
 */
int main(void)
{

#ifdef FEATURE_SPI_FLASH
	/* Put the SPI flash into Deep Power Down mode for those radio boards where it is available */
	MX25_init();
	MX25_DP();
	/* We must disable SPI communication */
	USART_Reset(USART1);

#endif /* FEATURE_SPI_FLASH */

	/* Initialize peripherals */
	enter_DefaultMode_from_RESET();

	/* Initialize stack */
	gecko_init(&config);

	while (1) {
		/* Event pointer for handling events */
		struct gecko_cmd_packet* evt;

		/* Check for stack event. */
		evt = gecko_wait_event();

		/* Handle events */
		switch (BGLIB_MSG_ID(evt->header)) {

		/* This boot event is generated when the system boots up after reset.
		 * Here the system is set to start advertising immediately after boot procedure. */
		case gecko_evt_system_boot_id:

			Clock_SetUp();
			LEUART_Setup();
			LDMA_SetUp();

			/* Set advertising parameters. 100ms advertisement interval. All channels used.
			 * The first two parameters are minimum and maximum advertising interval, both in
			 * units of (milliseconds * 1.6). The third parameter '7' sets advertising on all channels. */
			gecko_cmd_le_gap_set_adv_parameters(160,160,7);

			/* Start general advertising and enable connections. */
			gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
			break;

		case gecko_evt_le_connection_closed_id:

			/* Check if need to boot to dfu mode */
			if (boot_to_dfu) {
				/* Enter to DFU OTA mode */
				gecko_cmd_system_reset(2);
			}
			else {
				/* Restart advertising after client has disconnected */
				gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
			}
			break;


			/* Events related to OTA upgrading
      ----------------------------------------------------------------------------- */

			/* Check if the user-type OTA Control Characteristic was written.
			 * If ota_control was written, boot the device into Device Firmware Upgrade (DFU) mode. */
		case gecko_evt_gatt_server_user_write_request_id:

			if(evt->data.evt_gatt_server_user_write_request.characteristic==gattdb_ota_control)
			{
				/* Set flag to enter to OTA mode */
				boot_to_dfu = 1;
				/* Send response to Write Request */
				gecko_cmd_gatt_server_send_user_write_response(
						evt->data.evt_gatt_server_user_write_request.connection,
						gattdb_ota_control,
						bg_err_success);

				/* Close connection to enter to DFU OTA mode */
				gecko_cmd_endpoint_close(evt->data.evt_gatt_server_user_write_request.connection);
			}
			break;

		default:
			break;
		}
	}
	return 0;
}


/** @} (end addtogroup app) */
/** @} (end addtogroup Application) */
