/***********************************************************************************************//**
 * \file   app.c
 * \brief  Application code
 ***************************************************************************************************
 * <b> (C) Copyright 2015 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 **************************************************************************************************/

/* standard library headers */
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

/* BG stack headers */
#include "bg_types.h"
#include "native_gecko.h"

/* profiles */
#include "htm.h"
#include "ia.h"

/* BG stack headers*/
#include "gatt_db.h"

/* em library */
#include "em_system.h"
#include "em_cmu.h"
#include "em_gpio.h"

/* application specific headers */
#include "app_ui.h"
#include "app_hw.h"
#include "advertisement.h"
#include "beacon.h"
#include "app_timer.h"
#include "board_features.h"

/* Own header */
#include "app.h"

bd_addr slave_bluetooth_addr;
uint8_t slave_bluetooth_addr_type = 0;
uint8_t slave_conn_handle = 0;
uint32 slave_service_handle = 0;
uint8array slave_service_uuid;
uint16 slave_characteristic_handle = 0;
uint8 slave_characteristic_properties = 0;
uint8array slave_characteristic_uuid;
uint8 connection;
uint16 interval;
uint16 latency;
uint16 timeout;
uint16 result;
uint8 security_mode;
uint16 txsize;

const uint8_t temp_service_uuid[]  = "\x18\x09";
const uint8_t temp_char_uuid[]  = "\x2A\x1C";

/***********************************************************************************************//**
 * @addtogroup Application
 * @{
 **************************************************************************************************/

/***********************************************************************************************//**
 * @addtogroup app
 * @{
 **************************************************************************************************/


/***************************************************************************************************
  Local Macros and Definitions
 **************************************************************************************************/

/***************************************************************************************************
 Local Variables
 **************************************************************************************************/

/***************************************************************************************************
 Static Function Declarations
 **************************************************************************************************/
   #ifndef FEATURE_IOEXPANDER
 /* Periodically called Display Polarity Inverter Function for the LCD.
  Toggles the the EXTCOMIN signal of the Sharp memory LCD panel, which prevents building up a DC 
  bias according to the LCD's datasheet */
static void (*dispPolarityInvert)(void *);
  #endif /* FEATURE_IOEXPANDER */

/***************************************************************************************************
 Function Definitions
 **************************************************************************************************/

/***********************************************************************************************//**
 * \brief Function that initializes the device name, LEDs, buttons and services.
 **************************************************************************************************/
void appInit(void)
{
  /* Unique device ID */
  uint16_t devId;
  struct gecko_msg_system_get_bt_address_rsp_t* btAddr;
  char devName[APP_DEVNAME_LEN + 1];

  /* Init device name */
  /* Get the unique device ID */

  /* Create the device name based on the 16-bit device ID */
  btAddr = gecko_cmd_system_get_bt_address();
  devId = *((uint16*)(btAddr->address.addr));
  snprintf(devName, APP_DEVNAME_LEN + 1, APP_DEVNAME, devId);
  gecko_cmd_gatt_server_write_attribute_value(gattdb_device_name,
                                              0,
                                              strlen(devName),
                                              (uint8_t *)devName);

  /* Initialize LEDs, buttons, graphics. */
  //appUiInit(devId);

  /* Hardware initialization. Initializes temperature sensor. */
  //appHwInit();

  /* Initialize services */
  //htmInit();
}

/***********************************************************************************************//**
 * \brief Event handler function
 * @param[in] evt Event pointer
 **************************************************************************************************/
void appHandleEvents(struct gecko_cmd_packet *evt)
{
	/* Flag for indicating DFU Reset must be performed */
	static uint8_t boot_to_dfu = 0;

	switch (BGLIB_MSG_ID(evt->header)) {

	/* Boot event and connection closed event */
	case gecko_evt_system_boot_id:

		/* Initialize app */
		appInit(); /* App initialization */
		//htmInit(); /* Health thermometer initialization */
		//advSetup(); /* Advertisement initialization */

		/* This code configures this blue gecko as a master.
		 * The master will try to discover all the primary services and characteristics
		 * supported by a slave device (another blue gecko device ) */

		/* -------------------------------------------------------------------------- */
		/* Code for the link loss service example */

		/* LED0 - Power LED */
		//GPIO_PinModeSet(gpioPortF, 4, gpioModePushPull, 0);

		/* start the GAP discovery procedure to scan for advertising devices */
		/* Configure the scanning parameters */
		/* scan_interval - 800
		 * scan_window - 800
		 * passive scan mode */
		//gecko_cmd_le_gap_set_scan_parameters(100, 100, 1);

		/* Start the GAP discovery */
		//gecko_cmd_le_gap_discover(le_gap_general_discoverable); /* Discover using general discoverable mode */
		gecko_cmd_le_gap_discover(le_gap_discover_observation); /* Discover all devices */

		break;

		/* This event is generated when a connected client has either
		 * 1) changed a Characteristic Client Configuration, meaning that they have enabled
		 * or disabled Notifications or Indications, or
		 * 2) sent a confirmation upon a successful reception of the indication. */

	case gecko_evt_le_gap_scan_response_id:
		/* This event is triggered in response to gecko_cmd_le_gap_discover command */
		/* It reports any advertisement or scan response packet
		 * that is received by the device's radio while in scanning mode */
		/* TODO: Can add a check for bluetooth MAC address to identify the correct slave device */
#if 0
		if (evt->data.evt_le_gap_scan_response.packet_type == 0x00)
		{
			/* Type of packet received in scan_response is
			 * connectable undirected advertising packet type */
			if (NULL != slave_bluetooth_addr.addr
					&& NULL != evt->data.evt_le_gap_scan_response.address.addr)
				memcpy(slave_bluetooth_addr.addr, evt->data.evt_le_gap_scan_response.address.addr, sizeof(bd_addr));

			slave_bluetooth_addr_type = evt->data.evt_le_gap_scan_response.address_type;

			//gecko_cmd_le_gap_set_scan_parameters(100, 100, 1);

			//gecko_cmd_le_gap_end_procedure();

			gecko_cmd_le_gap_open(slave_bluetooth_addr, slave_bluetooth_addr_type);
		}
#else
		memcpy(slave_bluetooth_addr.addr, evt->data.evt_le_gap_scan_response.address.addr, sizeof(bd_addr));
		slave_bluetooth_addr_type = evt->data.evt_le_gap_scan_response.address_type;
		gecko_cmd_le_gap_end_procedure();
		gecko_cmd_le_gap_open(slave_bluetooth_addr, slave_bluetooth_addr_type);
#endif
		break;

		/* Connection opened event */
	case gecko_evt_le_connection_opened_id:
		/* Call advertisement.c connection started callback */
		//advConnectionStarted();
		/* Connection Open Event */
#if 0
		/* This event is triggered in response to gecko_cmd_le_gap_open event */
		if (NULL != evt->data.evt_le_connection_opened.address.addr
							&& NULL != slave_bluetooth_addr.addr)
		{
			if (memcmp(evt->data.evt_le_connection_opened.address.addr,
					slave_bluetooth_addr.addr, sizeof(bd_addr)) == 0)
			{
				slave_conn_handle = evt->data.evt_le_connection_opened.connection;

				/* Discover all the primary services defined in the
				 * GATT database for the slave identified by the
				 * newly acquired connection handle */
				//gecko_cmd_gatt_discover_primary_services(slave_conn_handle);

				gecko_cmd_gatt_discover_primary_services_by_uuid(
						slave_conn_handle, 2, temp_service_uuid);
			}
		}
#else
		slave_conn_handle = evt->data.evt_le_connection_opened.connection;
		gecko_cmd_gatt_discover_primary_services_by_uuid(slave_conn_handle, 2, temp_service_uuid);
#endif

		break;

	case gecko_evt_gatt_server_attribute_value_id:
		if ( evt->data.evt_gatt_server_attribute_value.attribute == gattdb_temp_measurement)
		{
			uint8array* rdata = &evt->data.evt_gatt_server_attribute_value.value;
		}
		break;

#if 0
	case gecko_evt_le_connection_parameters_id:
		connection = evt->data.evt_le_connection_parameters.connection;
		latency = evt->data.evt_le_connection_parameters.latency;
		interval = evt->data.evt_le_connection_parameters.interval;
		timeout = evt->data.evt_le_connection_parameters.timeout;
		security_mode = evt->data.evt_le_connection_parameters.security_mode;
		txsize = evt->data.evt_le_connection_parameters.txsize;

		break;
#endif

	case gecko_evt_gatt_service_id:
		/* This event is triggered in response to the gecko_cmd_gatt_discover_primary_services event */
#if 0
		if (evt->data.evt_gatt_service.connection == slave_conn_handle)
		{
			slave_service_handle = evt->data.evt_gatt_service.service;
		}
#else
		slave_service_handle = evt->data.evt_gatt_service.service;
#endif

		break;

	case gecko_evt_gatt_procedure_completed_id:
		if ( slave_service_handle > 0 )
		{
			gecko_cmd_gatt_discover_characteristics(evt->data.evt_gatt_procedure_completed.connection,
				slave_service_handle);
		}
		else
		{
			gecko_cmd_endpoint_close(slave_conn_handle);
		}

		break;

	case gecko_evt_gatt_characteristic_id:
		/* This event is triggered in response to the gecko_cmd_gatt_discover_characteristics event */
		if (memcmp(evt->data.evt_gatt_characteristic.uuid.data, temp_char_uuid, 2) == 0)
		{
			slave_characteristic_handle = evt->data.evt_gatt_characteristic.characteristic;
		}
		break;

	case gecko_evt_gatt_characteristic_value_id:
		//process receiving data
		if ( evt->data.evt_gatt_characteristic_value.characteristic == slave_characteristic_handle)
		{
			uint8array* rdata = &evt->data.evt_gatt_characteristic_value.value;
		}
		break;

	case gecko_evt_le_connection_closed_id:

		/* Initialize app */
		appInit(); /* App initialization */
		//htmInit(); /* Health thermometer initialization */
		//advSetup(); /* Advertisement initialization */

		/* Enter to DFU OTA mode if needed */
		if (boot_to_dfu) {
			gecko_cmd_system_reset(2);
		}

		/* Start the GAP discovery */
		gecko_cmd_le_gap_discover(le_gap_general_discoverable); /* Discover using general discoverable mode */

		break;

		/* Software Timer event */
	case gecko_evt_hardware_soft_timer_id:
		/* Check which software timer handle is in question */
		switch (evt->data.evt_hardware_soft_timer.handle) {
		case UI_TIMER: /* App UI Timer (LEDs, Buttons) */
			appUiTick();
			break;
		case ADV_TIMER: /* Advertisement Timer */
			advSetup();
			break;
#ifndef FEATURE_IOEXPANDER
		case DISP_POL_INV_TIMER:
			/*Toggle the the EXTCOMIN signal, which prevents building up a DC bias  within the
			 * Sharp memory LCD panel */
			dispPolarityInvert(0);
			break;
#endif /* FEATURE_IOEXPANDER */
		default:
			break;
		}
		break;
		/* User write request event. Checks if the user-type OTA Control Characteristic was written.
		 * If written, boots the device into Device Firmware Upgrade (DFU) mode. */
		case gecko_evt_gatt_server_user_write_request_id:
			/* Handle OTA */
			if(evt->data.evt_gatt_server_user_write_request.characteristic==gattdb_ota_control)
			{
				/* Set flag to enter to OTA mode */
				boot_to_dfu = 1;
				/* Send response to Write Request */
				gecko_cmd_gatt_server_send_user_write_response(
						evt->data.evt_gatt_server_user_write_request.connection,
						gattdb_ota_control,
						bg_err_success);

				/* Close connection to enter to DFU OTA mode */
				gecko_cmd_endpoint_close(evt->data.evt_gatt_server_user_write_request.connection);
			}
			break;

		default:
			break;
	}
}

/**************************************************************************//**
 * @brief   Register a callback function at the given frequency.
 *
 * @param[in] pFunction  Pointer to function that should be called at the
 *                       given frequency.
 * @param[in] argument   Argument to be given to the function.
 * @param[in] frequency  Frequency at which to call function at.
 *
 * @return  0 for successful or
 *         -1 if the requested frequency does not match the RTC frequency.
 *****************************************************************************/
int rtcIntCallbackRegister(void (*pFunction)(void*),
                           void* argument,
                           unsigned int frequency)
{
  #ifndef FEATURE_IOEXPANDER
  
  dispPolarityInvert =  pFunction;
  /* Start timer with required frequency */
  gecko_cmd_hardware_set_soft_timer(TIMER_MS_2_TIMERTICK(1000/frequency), DISP_POL_INV_TIMER, false);
  
  #endif /* FEATURE_IOEXPANDER */

  return 0;
}


/** @} (end addtogroup app) */
/** @} (end addtogroup Application) */
