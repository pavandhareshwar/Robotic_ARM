#ifndef _MCIOT_TIMER_H_
#define _MCIOT_TIMER_H_
#endif

/************************************ INCLUDES **************************************/

#include "em_timer.h"

/************************************ INCLUDES **************************************/

/****************************** FUNCTION PROTOTYPES *********************************/

void TIMER_Setup(TIMER_TypeDef *timer, TIMER_Init_TypeDef timerInit);

/****************************** FUNCTION PROTOTYPES *********************************/
